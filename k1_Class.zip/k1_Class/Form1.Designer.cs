﻿namespace k1_Class
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOgrenciOlustur = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.lblKanGrubu = new System.Windows.Forms.Label();
            this.lblAdres = new System.Windows.Forms.Label();
            this.lblBolumu = new System.Windows.Forms.Label();
            this.lblNumarasi = new System.Windows.Forms.Label();
            this.btnArabaEkle = new System.Windows.Forms.Button();
            this.txtMarka = new System.Windows.Forms.TextBox();
            this.txtModelAdi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtModelYili = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtMarka1 = new System.Windows.Forms.TextBox();
            this.txtModelAdi1 = new System.Windows.Forms.TextBox();
            this.txtModelYili1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnOgrenciOlustur
            // 
            this.btnOgrenciOlustur.Location = new System.Drawing.Point(103, 69);
            this.btnOgrenciOlustur.Margin = new System.Windows.Forms.Padding(4);
            this.btnOgrenciOlustur.Name = "btnOgrenciOlustur";
            this.btnOgrenciOlustur.Size = new System.Drawing.Size(168, 28);
            this.btnOgrenciOlustur.TabIndex = 0;
            this.btnOgrenciOlustur.Text = "Yeni Ogrenci Olustur";
            this.btnOgrenciOlustur.UseVisualStyleBackColor = true;
            this.btnOgrenciOlustur.Click += new System.EventHandler(this.btnOgrenciOlustur_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 133);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 164);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Soyad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(100, 196);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Kan Grubu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 225);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Adres";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 260);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Bölümü";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(100, 287);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Numarası";
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.Location = new System.Drawing.Point(205, 133);
            this.lblAd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(46, 17);
            this.lblAd.TabIndex = 7;
            this.lblAd.Text = "label7";
            // 
            // lblSoyad
            // 
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.Location = new System.Drawing.Point(205, 164);
            this.lblSoyad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(46, 17);
            this.lblSoyad.TabIndex = 8;
            this.lblSoyad.Text = "label8";
            // 
            // lblKanGrubu
            // 
            this.lblKanGrubu.AutoSize = true;
            this.lblKanGrubu.Location = new System.Drawing.Point(205, 196);
            this.lblKanGrubu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKanGrubu.Name = "lblKanGrubu";
            this.lblKanGrubu.Size = new System.Drawing.Size(46, 17);
            this.lblKanGrubu.TabIndex = 9;
            this.lblKanGrubu.Text = "label9";
            // 
            // lblAdres
            // 
            this.lblAdres.AutoSize = true;
            this.lblAdres.Location = new System.Drawing.Point(205, 225);
            this.lblAdres.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(54, 17);
            this.lblAdres.TabIndex = 10;
            this.lblAdres.Text = "label10";
            // 
            // lblBolumu
            // 
            this.lblBolumu.AutoSize = true;
            this.lblBolumu.Location = new System.Drawing.Point(205, 260);
            this.lblBolumu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBolumu.Name = "lblBolumu";
            this.lblBolumu.Size = new System.Drawing.Size(54, 17);
            this.lblBolumu.TabIndex = 11;
            this.lblBolumu.Text = "label11";
            // 
            // lblNumarasi
            // 
            this.lblNumarasi.AutoSize = true;
            this.lblNumarasi.Location = new System.Drawing.Point(205, 287);
            this.lblNumarasi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumarasi.Name = "lblNumarasi";
            this.lblNumarasi.Size = new System.Drawing.Size(54, 17);
            this.lblNumarasi.TabIndex = 12;
            this.lblNumarasi.Text = "label12";
            // 
            // btnArabaEkle
            // 
            this.btnArabaEkle.Location = new System.Drawing.Point(581, 69);
            this.btnArabaEkle.Margin = new System.Windows.Forms.Padding(4);
            this.btnArabaEkle.Name = "btnArabaEkle";
            this.btnArabaEkle.Size = new System.Drawing.Size(136, 28);
            this.btnArabaEkle.TabIndex = 13;
            this.btnArabaEkle.Text = "Araba Ekle";
            this.btnArabaEkle.UseVisualStyleBackColor = true;
            this.btnArabaEkle.Click += new System.EventHandler(this.btnArabaEkle_Click);
            // 
            // txtMarka
            // 
            this.txtMarka.Location = new System.Drawing.Point(581, 130);
            this.txtMarka.Name = "txtMarka";
            this.txtMarka.Size = new System.Drawing.Size(100, 22);
            this.txtMarka.TabIndex = 14;
            // 
            // txtModelAdi
            // 
            this.txtModelAdi.Location = new System.Drawing.Point(581, 159);
            this.txtModelAdi.Name = "txtModelAdi";
            this.txtModelAdi.Size = new System.Drawing.Size(100, 22);
            this.txtModelAdi.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(496, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 17);
            this.label7.TabIndex = 16;
            this.label7.Text = "Marka";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(496, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Model Adi";
            // 
            // txtModelYili
            // 
            this.txtModelYili.Location = new System.Drawing.Point(581, 196);
            this.txtModelYili.Name = "txtModelYili";
            this.txtModelYili.Size = new System.Drawing.Size(100, 22);
            this.txtModelYili.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(496, 196);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Model Yılı";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(498, 276);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 17);
            this.label10.TabIndex = 16;
            this.label10.Text = "Marka";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(498, 307);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 17);
            this.label11.TabIndex = 17;
            this.label11.Text = "Model Adi";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(498, 339);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 17);
            this.label12.TabIndex = 19;
            this.label12.Text = "Model Yılı";
            // 
            // txtMarka1
            // 
            this.txtMarka1.Location = new System.Drawing.Point(581, 270);
            this.txtMarka1.Name = "txtMarka1";
            this.txtMarka1.Size = new System.Drawing.Size(100, 22);
            this.txtMarka1.TabIndex = 14;
            // 
            // txtModelAdi1
            // 
            this.txtModelAdi1.Location = new System.Drawing.Point(581, 299);
            this.txtModelAdi1.Name = "txtModelAdi1";
            this.txtModelAdi1.Size = new System.Drawing.Size(100, 22);
            this.txtModelAdi1.TabIndex = 15;
            // 
            // txtModelYili1
            // 
            this.txtModelYili1.Location = new System.Drawing.Point(581, 336);
            this.txtModelYili1.Name = "txtModelYili1";
            this.txtModelYili1.Size = new System.Drawing.Size(100, 22);
            this.txtModelYili1.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtModelYili1);
            this.Controls.Add(this.txtModelYili);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtModelAdi1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMarka1);
            this.Controls.Add(this.txtModelAdi);
            this.Controls.Add(this.txtMarka);
            this.Controls.Add(this.btnArabaEkle);
            this.Controls.Add(this.lblNumarasi);
            this.Controls.Add(this.lblBolumu);
            this.Controls.Add(this.lblAdres);
            this.Controls.Add(this.lblKanGrubu);
            this.Controls.Add(this.lblSoyad);
            this.Controls.Add(this.lblAd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnOgrenciOlustur);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOgrenciOlustur;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.Label lblSoyad;
        private System.Windows.Forms.Label lblKanGrubu;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.Label lblBolumu;
        private System.Windows.Forms.Label lblNumarasi;
        private System.Windows.Forms.Button btnArabaEkle;
        private System.Windows.Forms.TextBox txtMarka;
        private System.Windows.Forms.TextBox txtModelAdi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtModelYili;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtMarka1;
        private System.Windows.Forms.TextBox txtModelAdi1;
        private System.Windows.Forms.TextBox txtModelYili1;
    }
}

